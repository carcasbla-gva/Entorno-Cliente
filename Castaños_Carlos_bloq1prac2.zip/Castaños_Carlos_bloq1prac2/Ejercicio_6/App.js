function mostrarHoraYSaludo() {
    let ahora = new Date();
    let hora = ahora.getHours();
    let minutos = ahora.getMinutes();

    if (minutos < 10){
        minutos = "0" + minutos;
    }
    let saludo = " ";

    if (hora >= 6 && hora < 14) {
        saludo = "Buenos días";
    }
    else if (hora >= 14 && hora < 20) {
        saludo = "Buenas tardes";
    }
    else {
        saludo = "Buenas noches";
    }

    let mensaje = saludo + ", son las " + hora + ":" + minutos + "horas";
    document.getElementById("salidaHora").textContent = mensaje;
}