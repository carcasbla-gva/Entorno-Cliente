let agente = navigator.userAgent;

let esIE = agente.indexOf("MSIE") !== -1 || agente.indexOf("Trident") !== -1;

if (esIE) {
    window.resizeTo(500, 500);
} else {
    alert("Operación no permitida con este navegador");
}