// Añade un párrafo detrás del último párrafo creado
function anyadirParrafo() {
    var div = document.getElementById("divisor");
    var nuevoP = document.createElement("p");
    var texto = document.createTextNode("Párrafo añadido");
    nuevoP.appendChild(texto);
    div.appendChild(nuevoP);
}

// Inserta un párrafo detrás del primer párrafo inicial
function insertarParrafo() {
    var div = document.getElementById("divisor");
    var parrafos = div.getElementsByTagName("p");

    if (parrafos.length >= 1) {
        var nuevoP = document.createElement("p");
        var texto = document.createTextNode("Párrafo insertado");
        nuevoP.appendChild(texto);

        // Si existe un segundo párrafo, se inserta antes de él (quedando detrás del primero)
        if (parrafos.length > 1) {
            div.insertBefore(nuevoP, parrafos[1]);
        } else {
            div.appendChild(nuevoP);
        }
    }
}

// Reemplaza el segundo párrafo por "Párrafo reemplazado"
function reemplazarParrafo() {
    var div = document.getElementById("divisor");
    var parrafos = div.getElementsByTagName("p");

    if (parrafos.length > 1) {
        var nuevoP = document.createElement("p");
        var texto = document.createTextNode("Párrafo reemplazado");
        nuevoP.appendChild(texto);

        // Reemplaza el nodo en la posición 1 del segundo párrafo
        div.replaceChild(nuevoP, parrafos[1]);
    } else {
        alert("No existe un segundo párrafo para reemplazar.");
    }
}

// Elimina el párrafo que haya inmediatamente detrás del primero
function borrarParrafo() {
    var div = document.getElementById("divisor");
    var parrafos = div.getElementsByTagName("p");

    if (parrafos.length > 1) {
        div.removeChild(parrafos[1]);
    } else {
        alert("No hay ningún párrafo detrás del primero para borrar.");
    }
}

// Clona toda la estructura del div con sus hijos (deep clone: true) y la añade al body
function clonarDiv() {
    var div = document.getElementById("divisor");
    var divClonado = div.cloneNode(true);
    document.body.appendChild(divClonado);
}